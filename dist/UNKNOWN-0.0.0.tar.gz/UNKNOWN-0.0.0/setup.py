#!/usr/bin/env python

from distutils.core import setup
from distutils.command.install_egg_info import install_egg_info as _install_egg_info
import time

setup(name        = 'fastaRename',
      version     =  time.strftime("%Y%m%d"),
      author      = "Neron B",
      author_email = "bneron@pasteur.fr" ,
      license      = "GPLv2" ,
      description  = """parse a file with fasta sequences
replace the identifier of a fasta sequences by a short identifier
and generate a file with renamed fasta sequences and a file of mapping """,
      classifiers = [
                     'License :: GPLv2' ,
                     'Operating System :: POSIX' ,
                     'Programming Language :: Python' ,
                     'Topic :: Bioinformatics' ,
                    ] ,
      scripts     = [ 'src/fastaRename' ] ,
      )

class nohup_egg_info(_install_egg_info):
  def run(self):
    #there is nothing to install in sites-package
    #so I don't put any eggs in it
    pass

cmdclass = { 'install_egg_info': nohup_egg_info }

setup( cmdclass=cmdclass )